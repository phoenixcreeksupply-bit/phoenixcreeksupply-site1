// components/Header.js
export default function Header() {
  return (
    <header className="header">
      <div className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 20px'}}>
        <a href="/" style={{fontWeight:600, letterSpacing:'0.2px'}}>Phoenix Creek Supply</a>
        <nav className="nav">
          <a href="/">Home</a>
          <a href="/guide">Field Guide</a>
          <a href="/gear">Gear</a>
          <a href="/about">About</a>
          <a href="/contact">Contact</a>
          <a href="/newsletter">Newsletter</a>
        </nav>
      </div>
    </header>
  );
}
