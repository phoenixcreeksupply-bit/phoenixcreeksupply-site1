// pages/_app.js
import '../styles/globals.css'
import Head from 'next/head'
import Script from 'next/script'
import Header from '../components/Header'

export default function App({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#ffffff" />
        <meta property="og:site_name" content="Phoenix Creek Supply" />
        <meta property="og:type" content="website" />
      </Head>

      {/* GA4 */}
      <Script src="https://www.googletagmanager.com/gtag/js?id=G-500338019" strategy="afterInteractive" />
      <Script id="ga4" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'G-500338019');
        `}
      </Script>

      <Header />
      <main>
        <Component {...pageProps} />
      </main>

      <footer className="footer">
        <div className="container" style={{display:'flex',gap:'16px',flexWrap:'wrap',justifyContent:'space-between'}}>
          <p>Field-tested by Monroe · Patience is a Virtue</p>
          <p className="small">As an Amazon Associate, we earn from qualifying purchases.</p>
          <nav className="small" style={{display:'flex',gap:'12px'}}>
            <a href="/disclaimer" className="link">Disclaimer</a>
            <a href="/terms" className="link">Terms</a>
            <a href="/privacy" className="link">Privacy</a>
          </nav>
        </div>
      </footer>
    </>
  )
}
