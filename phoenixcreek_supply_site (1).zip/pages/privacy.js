// pages/privacy.js
export default function Privacy() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>Privacy Policy</h1>
      <p className="muted" style={{marginBottom:12}}>
        We respect your privacy. If you give us your email, it’s for updates, offers, and content we think you’ll value.
        We do not sell or rent your personal information.
      </p>
      <p className="muted" style={{marginBottom:12}}>
        Like most websites, we use analytics to understand what’s working. You can block cookies in your browser if you wish.
      </p>
      <p className="muted">
        For data requests, contact us via the address on the Contact page.
      </p>
    </main>
  )
}
