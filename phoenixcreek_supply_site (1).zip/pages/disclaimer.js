// pages/disclaimer.js
export default function Disclaimer() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>Affiliate & Earnings Disclaimer</h1>
      <p className="muted" style={{marginBottom:12}}>
        Out here, we recommend only the gear and tools we’d trust in our own pack. Some links on Phoenix Creek Supply are affiliate links,
        meaning if you click and buy, we may earn a small commission — at no extra cost to you.
      </p>
      <p className="muted" style={{marginBottom:12}}>
        This helps keep the lights on and the site growing. If it’s here, it’s been field-tested or comes from a brand we trust.
      </p>
      <p className="muted">
        Bottom line: you’re responsible for choosing what’s right for you, your skills, and your situation. Use your head and don’t outsource common sense.
      </p>
    </main>
  )
}
