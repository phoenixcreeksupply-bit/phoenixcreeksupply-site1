// pages/gear.js
import { sections } from '../data/gear'

export default function Gear() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <header style={{marginBottom:16}}>
        <h1 style={{fontSize:'32px',fontWeight:700}}>Gear</h1>
        <p className="muted" style={{marginTop:8}}>
          Curated, field-ready picks. Some links are affiliate links — your purchase may earn us a small commission at no extra cost to you.
          We recommend what we’d carry.
        </p>
      </header>

      {sections.map((sec) => (
        <section key={sec.heading} style={{marginBottom:40}}>
          <h2 style={{fontSize:'24px',fontWeight:600, marginBottom:12}}>{sec.heading}</h2>
          <div className="grid grid-3">
            {sec.items.map((item) => (
              <article key={item.title} className="card" style={{overflow:'hidden'}}>
                <a href={item.href} target="_blank" rel="nofollow sponsored noopener" title={item.title} className="block">
                  <div className="aspect16x9">
                    <img src={item.img} alt={item.title} loading="lazy" />
                  </div>
                  <div style={{paddingTop:12}}>
                    <h3 style={{fontSize:'18px',fontWeight:600}}>{item.title}</h3>
                    <p className="muted" style={{marginTop:6}}>{item.blurb}</p>
                    <span className="small" style={{display:'inline-block', marginTop:10}}>Check on Amazon →</span>
                  </div>
                </a>
              </article>
            ))}
          </div>
        </section>
      ))}
    </main>
  )
}
