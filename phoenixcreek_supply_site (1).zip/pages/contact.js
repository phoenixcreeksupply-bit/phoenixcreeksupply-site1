// pages/contact.js
export default function Contact() {
  const EMAIL = "monroehall0911@gmail.com";
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>Contact</h1>
      <p className="muted" style={{marginBottom:16}}>Questions, partnerships, or field stories — send it our way.</p>
      <a className="btn" href={`mailto:${EMAIL}`}>Email Us</a>
    </main>
  )
}
