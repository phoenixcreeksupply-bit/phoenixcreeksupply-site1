// pages/about.js
export default function About() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>About Phoenix Creek Supply</h1>
      <p className="muted">
        Built for the modern stoic. We test gear, write guides, and share what works in the field.
        No noise. No gimmicks. Just tools you can trust when conditions get real.
      </p>
    </main>
  )
}
