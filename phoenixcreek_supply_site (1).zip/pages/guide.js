// pages/guide.js
import Head from 'next/head'
import Script from 'next/script'

export default function Guide() {
  const gumroadUrl = "https://phoenixcreeksupply.gumroad.com/l/gzxqj";

  return (
    <>
      <Head>
        <title>The Modern Stoic Field Guide | Phoenix Creek Supply</title>
        <meta name="description" content="Daily prompts, field wisdom, and practical mental models to steady your mind and sharpen your edge." />
      </Head>
      <Script src="https://gumroad.com/js/gumroad.js" strategy="afterInteractive" />
      <main className="container" style={{padding:'32px 20px'}}>
        <header style={{marginBottom:24}}>
          <h1 style={{fontSize:'36px',fontWeight:800, lineHeight:1.1}}>The Modern Stoic Field Guide</h1>
          <p className="muted" style={{fontSize:'18px', marginTop:8}}>A compact, field-ready system for calm action and durable results. No fluff. No noise.</p>
        </header>

        <section className="card" style={{marginBottom:24}}>
          <h2 style={{fontSize:'22px',fontWeight:700, marginBottom:8}}>Get the Guide</h2>
          <p className="muted" style={{marginBottom:12}}>Instant digital download (PDF). Lifetime updates included.</p>
          <a className="btn gumroad-button" href={gumroadUrl}>Buy Now on Gumroad</a>
        </section>

        <section className="grid grid-3">
          <div className="card">
            <h3 style={{fontWeight:600, marginBottom:6}}>Daily Pages</h3>
            <p className="muted">AM/PM prompts that fit on one page. Stay consistent.</p>
          </div>
          <div className="card">
            <h3 style={{fontWeight:600, marginBottom:6}}>Decision OS</h3>
            <p className="muted">Simple matrices to de-clutter choices under pressure.</p>
          </div>
          <div className="card">
            <h3 style={{fontWeight:600, marginBottom:6}}>After-Action Notes</h3>
            <p className="muted">Tight debrief loop. Wins, frictions, and fixes.</p>
          </div>
        </section>
      </main>
    </>
  )
}
