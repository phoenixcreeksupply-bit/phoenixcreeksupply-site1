// pages/index.js
import Head from 'next/head'

const AMAZON_PROSPECTOR = "https://www.amazon.com/s?k=gold+panning+kit&tag=phoenixcreekg-20";
const AMAZON_GPS = "https://www.amazon.com/s?k=handheld+gps+garmin&tag=phoenixcreekg-20";
const GUMROAD_URL = "https://phoenixcreeksupply.gumroad.com/l/gzxqj";

export default function Home() {
  return (
    <>
      <Head>
        <title>Phoenix Creek Supply</title>
        <meta name="description" content="Rugged tools for the Modern Stoic—field-tested kits, navigation, and guides." />
      </Head>

      <section className="container hero">
        <h1 style={{fontSize:'42px',fontWeight:800, lineHeight:1.1, marginBottom:8}}>Welcome to Phoenix Creek Supply</h1>
        <p className="muted" style={{fontSize:'18px'}}>Rugged tools for the Modern Stoic.</p>
        <span className="space" />
      </section>

      <section className="container section" id="featured-gear">
        <div style={{display:'flex',alignItems:'flex-end',justifyContent:'space-between',marginBottom:12}}>
          <h2 style={{fontSize:'28px',fontWeight:700}}>Featured Gear</h2>
          <a href="#featured-gear" className="link small">View All Gear</a>
        </div>

        <div className="grid grid-3">
          <article className="card">
            <h3 className="text-xl" style={{fontSize:'20px',fontWeight:600}}>Prospector Essentials Kit</h3>
            <p className="muted" style={{marginTop:8}}>A fundamental gold panning kit that includes permitting and claim documentation tools.</p>
            <ul className="muted" style={{marginTop:8, paddingLeft:18}}>
              <li>Pan, classifier, snuffer, vials</li>
              <li>Permit & claim quick-reference</li>
              <li>Field checklist</li>
            </ul>
            <a href="/gear" className="btn" style={{marginTop:14}}>View Kit →</a>
          </article>

          <article className="card">
            <h3 className="text-xl" style={{fontSize:'20px',fontWeight:600}}>Navigation Bundle</h3>
            <p className="muted" style={{marginTop:8}}>Stay on course with our digital navigation guide and in-the-field GPS bundle.</p>
            <ul className="muted" style={{marginTop:8, paddingLeft:18}}>
              <li>Offline topo & satellite workflow</li>
              <li>Waypoint, track, and grid basics</li>
              <li>Recommended GPS/compass</li>
            </ul>
            <a href={AMAZON_GPS} target="_blank" rel="noopener noreferrer nofollow sponsored" className="btn" style={{marginTop:14}}>Buy Now →</a>
          </article>

          <article className="card">
            <h3 className="text-xl" style={{fontSize:'20px',fontWeight:600}}>The Modern Stoic Field Guide</h3>
            <p className="muted" style={{marginTop:8}}>A no-noise daily carry: mental models, checklists, and prompts for clarity, discipline, and quiet power.</p>
            <ul className="muted" style={{marginTop:8, paddingLeft:18}}>
              <li>Daily prompts (3–5 minutes)</li>
              <li>Field checklists & gear notes</li>
              <li>Printable + mobile-friendly</li>
            </ul>
            <a href={GUMROAD_URL} target="_blank" rel="noopener" className="btn" style={{marginTop:14}}>Get the Guide →</a>
          </article>
        </div>
      </section>
    </>
  )
}
