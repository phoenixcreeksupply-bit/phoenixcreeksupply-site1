// pages/newsletter.js
export default function Newsletter() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>Join the Phoenix List</h1>
      <p className="muted" style={{marginBottom:16}}>No fluff. Gear drops, field guides, mission updates.</p>
      <div className="card">
        <p className="small muted">(Paste your ConvertKit or Beehiiv embed here when ready.)</p>
      </div>
    </main>
  )
}
