// pages/terms.js
export default function Terms() {
  return (
    <main className="container" style={{padding:'32px 20px'}}>
      <h1 style={{fontSize:'32px',fontWeight:700, marginBottom:12}}>Terms of Use</h1>
      <p className="muted" style={{marginBottom:12}}>
        We provide tools, guides, and recommendations for informational purposes only — how you use them is on you.
      </p>
      <p className="muted" style={{marginBottom:12}}>
        We are not responsible for injuries, losses, or outcomes from following our content or using recommended products.
      </p>
      <p className="muted">
        Use this site at your own risk. If you don’t agree with these terms, don’t use the site.
      </p>
    </main>
  )
}
